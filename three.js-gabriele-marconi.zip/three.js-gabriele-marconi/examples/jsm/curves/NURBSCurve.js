import {
	Curve,
	Vector3,
	Vector4,
	Matrix4,
	MathUtils,
} from 'three';
import * as NURBSUtils from '../curves/NURBSUtils.js';

/**
 * NURBS curve object
 *
 * Derives from Curve, overriding getPoint and getTangent.
 *
 * Implementation is based on (x, y [, z=0 [, w=1]]) control points with w=weight.
 *
 **/

class NURBSCurve extends Curve {

	constructor(
		degree,
		knots /* array of reals */,
		controlPoints /* array of Vector(2|3|4) */,
		startKnot /* index in knots */,
		endKnot /* index in knots */
	) {

		super();

		this.degree = degree;
		this.knots = knots;
		this.controlPoints = [];
		// Used by periodic NURBS to remove hidden spans
		this.startKnot = startKnot || 0;
		this.endKnot = endKnot || ( this.knots.length - 1 );

		for ( let i = 0; i < controlPoints.length; ++ i ) {

			// ensure Vector4 for control points
			const point = controlPoints[ i ];
			this.controlPoints[ i ] = new Vector4( point.x, point.y, point.z, point.w );

		}

	}

	getPoint( t, optionalTarget = new Vector3() ) {

		const point = optionalTarget;

		const u = this.knots[ this.startKnot ] + t * ( this.knots[ this.endKnot ] - this.knots[ this.startKnot ] ); // linear mapping t->u

		// following results in (wx, wy, wz, w) homogeneous point
		const hpoint = NURBSUtils.calcBSplinePoint( this.degree, this.knots, this.controlPoints, u );

		if ( hpoint.w !== 1.0 ) {

			// project to 3D space: (wx, wy, wz, w) -> (x, y, z, 1)
			hpoint.divideScalar( hpoint.w );

		}

		return point.set( hpoint.x, hpoint.y, hpoint.z );

	}

	getTangent( t, optionalTarget = new Vector3() ) {

		const tangent = optionalTarget;

		const u = this.knots[ 0 ] + t * ( this.knots[ this.knots.length - 1 ] - this.knots[ 0 ] );
		const ders = NURBSUtils.calcNURBSDerivatives( this.degree, this.knots, this.controlPoints, u, 1 );
		tangent.copy( ders[ 1 ] ).normalize();

		return tangent;

	}

//calcola tangente, binormale e normale in un
//punto di una curva in cui viene calcolato valore, derivata prima e seconda;
    computeFrenetFramesNew( t ){
	//vettori in cui vengono calcolati i vettori suddetti
	//var C0 = new Vector3();
	var C1 = new Vector3();
	var C2 = new Vector3();
	const tangent = new Vector3();
	const normal = new Vector3();
	const binormal = new Vector3();

	const ders = NURBSUtils.calcNURBSDerivatives( this.degree, this.knots, this.controlPoints, t, 2 );
	//C0.copy( ders[ 0 ] );
	C1.copy( ders[ 1 ] );
	C2.copy( ders[ 2 ] );
	
	//versore Tangente
	tangent.copy(C1).normalize();

	//versore Binormale
	binormal.crossVectors(C1,C2);
	binormal.normalize();

	//versore Normale
	normal.crossVectors(binormal,tangent);

	return {
		tangents: tangent,
		normals: normal,
		binormals: binormal
	};
  }

  computeFrenetFrames( segments, closed ) {

	// see http://www.cs.indiana.edu/pub/techreports/TR425.pdf

	const normal = new Vector3();

	const tangents = [];
	const normals = [];
	const binormals = [];

	const vec = new Vector3();
	const mat = new Matrix4();

	// compute the tangent vectors for each segment on the curve

	for ( let i = 0; i <= segments; i ++ ) {

		const u = i / segments;

		tangents[ i ] = this.getTangentAt( u, new Vector3() );

	}

	// select an initial normal vector perpendicular to the first tangent vector,
	// and in the direction of the minimum tangent xyz component

	normals[ 0 ] = new Vector3();
	binormals[ 0 ] = new Vector3();
	let min = Number.MAX_VALUE;
	const tx = Math.abs( tangents[ 0 ].x );
	const ty = Math.abs( tangents[ 0 ].y );
	const tz = Math.abs( tangents[ 0 ].z );

	if ( tx <= min ) {

		min = tx;
		normal.set( 1, 0, 0 );

	}

	if ( ty <= min ) {

		min = ty;
		normal.set( 0, 1, 0 );

	}

	if ( tz <= min ) {

		normal.set( 0, 0, 1 );

	}

	vec.crossVectors( tangents[ 0 ], normal ).normalize();

	normals[ 0 ].crossVectors( tangents[ 0 ], vec );
	binormals[ 0 ].crossVectors( tangents[ 0 ], normals[ 0 ] );


	// compute the slowly-varying normal and binormal vectors for each segment on the curve

	for ( let i = 1; i <= segments; i ++ ) {

		normals[ i ] = normals[ i - 1 ].clone();

		binormals[ i ] = binormals[ i - 1 ].clone();

		vec.crossVectors( tangents[ i - 1 ], tangents[ i ] );

		if ( vec.length() > Number.EPSILON ) {

			vec.normalize();

			const theta = Math.acos( MathUtils.clamp( tangents[ i - 1 ].dot( tangents[ i ] ), - 1, 1 ) ); // clamp for floating pt errors

			normals[ i ].applyMatrix4( mat.makeRotationAxis( vec, theta ) );

		}

		binormals[ i ].crossVectors( tangents[ i ], normals[ i ] );

	}

	// if the curve is closed, postprocess the vectors so the first and last normal vectors are the same

	if ( closed === true ) {

		let theta = Math.acos( MathUtils.clamp( normals[ 0 ].dot( normals[ segments ] ), - 1, 1 ) );
		theta /= segments;

		if ( tangents[ 0 ].dot( vec.crossVectors( normals[ 0 ], normals[ segments ] ) ) > 0 ) {

			theta = - theta;

		}

		for ( let i = 1; i <= segments; i ++ ) {

			// twist a little...
			normals[ i ].applyMatrix4( mat.makeRotationAxis( tangents[ i ], theta * i ) );
			binormals[ i ].crossVectors( tangents[ i ], normals[ i ] );

		}

	}

	return {
		tangents: tangents,
		normals: normals,
		binormals: binormals
	};
 
 }
			
}



export { NURBSCurve };
